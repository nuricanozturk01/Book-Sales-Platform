package nuricanozturk.dev.service.notification.config.kafka.consumer;

public enum EPaymentStatus
{
    SUCCESS, FAIL
}
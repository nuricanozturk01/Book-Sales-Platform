package nuricanozturk.dev.service.notification.config.kafka.consumer;

public enum BookStatus
{
    AVAILABLE, FINISHED
}

package nuricanozturk.dev.service.notification.dto;

public enum PaymentStatus
{
    SUCCESS, FAIL
}
